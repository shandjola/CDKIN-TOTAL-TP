import mysql.connector
import json

def myfonction():
    # Connexion à la base de données MySQL
    db = mysql.connector.connect(
        host="54.89.223.141",
        port=3306,
        user="lambda",
        password="password",
        database="cohorte"
    )

    # Création d'un curseur
    cursor = db.cursor()

    # Requête SQL pour récupérer les données
    query = "SELECT * FROM user"
    cursor.execute(query)

    # Récupération des résultats
    results = cursor.fetchall()

    # Conversion des résultats en JSON
    data = [dict(zip([column[0] for column in cursor.description], row)) for row in results]
    json_data = json.dumps(data)
    return {
        "statusCode": 200,
        "body": json_data
    }

print(myfonction())